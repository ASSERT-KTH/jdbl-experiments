package org.bukkit.entity;

/**
 * @deprecated This class has been moved into a sub package; {@link
 * org.bukkit.entity.minecart.StorageMinecart} should be used instead.
 * @see org.bukkit.entity.minecart.StorageMinecart
 */
@Deprecated
public interface StorageMinecart extends org.bukkit.entity.minecart.StorageMinecart {}
