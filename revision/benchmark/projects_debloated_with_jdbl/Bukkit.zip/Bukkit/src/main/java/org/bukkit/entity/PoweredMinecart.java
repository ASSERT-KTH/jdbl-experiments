package org.bukkit.entity;

/**
 * @deprecated This class has been moved into a sub package; {@link
 * org.bukkit.entity.minecart.PoweredMinecart} should be used instead.
 * @see org.bukkit.entity.minecart.PoweredMinecart
 */
@Deprecated
public interface PoweredMinecart extends org.bukkit.entity.minecart.PoweredMinecart {}
