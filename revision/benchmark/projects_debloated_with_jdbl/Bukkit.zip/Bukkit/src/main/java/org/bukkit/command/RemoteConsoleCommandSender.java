package org.bukkit.command;

public interface RemoteConsoleCommandSender extends CommandSender {
}
