package org.bukkit.scoreboard;

/**
 * Locations for displaying objectives to the player
 */
public enum DisplaySlot {
    BELOW_NAME,
    PLAYER_LIST,
    SIDEBAR;
}
