package org.bukkit.entity;

/**
 * Represents a thrown Ender Pearl entity
 */
public interface EnderPearl extends Projectile {

}
