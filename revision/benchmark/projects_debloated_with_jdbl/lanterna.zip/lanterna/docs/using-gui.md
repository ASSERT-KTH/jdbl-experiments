# Text GUI
_Please note: You should read the [Buffered screen API](using-screen.md) guide before you start reading this guide_

The guide on how to use the GUI is a bit too long for one page so it's been split up:
  * [Start the GUI](GUIGuideStartTheGUI.md)
  * [Basic windows](GUIGuideWindows.md)
  * [Components](GUIGuideComponents.md)
  * [Built-in dialogs](GUIGuideDialogs.md)
  * [Misc](GUIGuideMisc.md)