# Misc
**WARNING: This page has not yet been updated to Lanterna 3 and is out-of-date**
  * Multi-threading
  * Themes