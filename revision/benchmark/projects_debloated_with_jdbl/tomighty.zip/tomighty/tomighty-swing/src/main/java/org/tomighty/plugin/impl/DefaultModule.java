package org.tomighty.plugin.impl;

import com.google.inject.AbstractModule;

/**
 * @author dobermai
 */
public class DefaultModule extends AbstractModule {
    @Override
    protected void configure() {
        //Nothing to configure here because this is a Plugin default Module
    }
}
