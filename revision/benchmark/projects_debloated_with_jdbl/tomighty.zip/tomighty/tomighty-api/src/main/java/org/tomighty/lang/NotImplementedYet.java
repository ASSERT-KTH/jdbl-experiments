package org.tomighty.lang;

public class NotImplementedYet extends RuntimeException {
}
