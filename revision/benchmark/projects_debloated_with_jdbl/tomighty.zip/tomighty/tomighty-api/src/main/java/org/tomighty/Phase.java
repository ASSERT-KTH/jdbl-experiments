package org.tomighty;

public enum Phase {

    BREAK,
    POMODORO

}
