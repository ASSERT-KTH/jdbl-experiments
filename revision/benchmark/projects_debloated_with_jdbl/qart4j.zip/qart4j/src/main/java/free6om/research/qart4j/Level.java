package free6om.research.qart4j;

/**
 * Created by free6om on 7/20/15.
 */
public enum Level {
    L, M, Q, H
}
