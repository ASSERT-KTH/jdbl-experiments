package free6om.research.qart4j;

/**
 * Created by free6om on 7/20/15.
 */
public class PixelMatrix {
    private Pixel[][] pixels;
    private int width;
    private int height;
}
