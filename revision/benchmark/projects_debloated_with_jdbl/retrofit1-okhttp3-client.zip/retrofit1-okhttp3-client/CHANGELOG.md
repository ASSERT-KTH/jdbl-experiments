Change Log
==========

Version 1.1.0 *(2016-04-04)*
----------------------------

 * New: Coerce `null` request bodies from Retrofit to empty bodies for OkHttp.
 * Update to OkHttp 3.2.0.


Version 1.0.2 *(2016-01-15)*
----------------------------

 * Update to OkHttp 3.0 final.


Version 1.0.1 *(2016-01-03)*
----------------------------

 * Add constructor overload for `Call.Factory`.


Version 1.0.0 *(2016-01-02)*
----------------------------

Initial version.
