package junit.tests.framework;

import junit.framework.TestCase;

/**
 * Test class used in SuiteTest
 */
public class OneTestCase extends TestCase {
    public void noTestCase() {
    }

    public void testCase() {
    }

    public void testCase(int arg) {
    }
}