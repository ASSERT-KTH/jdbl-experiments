## Summary of Changes in version 4.8.1 ##

This was a quick bugfix release for an important bug

### Bug fixes ###

- github#61: Category annotations on classes were not honored.