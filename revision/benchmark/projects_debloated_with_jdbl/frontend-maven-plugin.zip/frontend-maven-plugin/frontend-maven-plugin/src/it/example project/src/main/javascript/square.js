function square(n){
    return n*n;
}