describe('The square function', function(){
    it('should square a number', function(){
        expect(square(3)).toBe(9);
    });
});