<!-- Before creating an issue please 
 - search for existing duplicate or closed issues 
 - make sure you are using the latest version of frontend-maven-plugin 
-->

**Do you want to request a _feature_ or report a _bug_?**

**What is the current behavior?**

**If the current behavior is a bug, please provide the steps to reproduce.**

**What is the expected behavior?**

**Please mention your frontend-maven-plugin and operating system version.**
