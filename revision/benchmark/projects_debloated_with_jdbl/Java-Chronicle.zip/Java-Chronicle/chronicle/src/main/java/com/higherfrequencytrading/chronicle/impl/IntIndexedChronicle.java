/*
 * Copyright 2013 Peter Lawrey
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.higherfrequencytrading.chronicle.impl;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Fast Chronicle with a compact index when you don't need more the 4 GB of data.
 *
 * @author peter.lawrey
 */
public class IntIndexedChronicle extends IndexedChronicle {
    private static final long LONG_MASK = -1L >>> 32;

    public IntIndexedChronicle(String basePath) throws IOException {
        super(basePath);
    }

    public IntIndexedChronicle(String basePath, int dataBitSizeHint) throws IOException {
        super(basePath, dataBitSizeHint);
    }

    public IntIndexedChronicle(String basePath, int dataBitSizeHint, ByteOrder byteOrder) throws IOException {
        super(basePath, dataBitSizeHint, byteOrder);
    }

    @Override
    public long getIndexData(long indexId) {
        long indexOffset = indexId << indexBitSize();
        MappedMemory mappedMemory = acquireIndexBuffer(indexOffset);
        ByteBuffer indexBuffer = mappedMemory.buffer();
        int num = indexBuffer.getInt((int) (indexOffset & indexLowMask));
        mappedMemory.release();
        return num & LONG_MASK;
    }

    @Override
    protected int indexBitSize() {
        return 2;
    }

    @Override
    public void setIndexData(long indexId, long indexData) {
        if (indexData >= (1L << 32))
            throw new IllegalStateException("Size of Chronicle too large > 4 GB");
        long indexOffset = indexId << indexBitSize();
        MappedMemory mappedMemory = acquireIndexBuffer(indexOffset);
        ByteBuffer indexBuffer = mappedMemory.buffer();
        assert indexData <= LONG_MASK;
        indexBuffer.putInt((int) (indexOffset & indexLowMask), (int) indexData);
        mappedMemory.release();
    }
}
