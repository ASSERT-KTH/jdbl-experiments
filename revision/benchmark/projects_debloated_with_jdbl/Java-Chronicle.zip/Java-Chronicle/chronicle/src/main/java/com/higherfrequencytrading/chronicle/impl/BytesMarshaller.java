/*
 * Copyright 2013 Peter Lawrey
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.higherfrequencytrading.chronicle.impl;

import com.higherfrequencytrading.chronicle.EnumeratedMarshaller;
import com.higherfrequencytrading.chronicle.Excerpt;
import com.higherfrequencytrading.chronicle.StopCharTester;
import org.jetbrains.annotations.NotNull;

import java.nio.charset.Charset;

/**
 * User: peter Date: 14/08/13 Time: 16:18
 */
public class BytesMarshaller implements EnumeratedMarshaller<byte[]> {
    @NotNull
    @Override
    public Class<byte[]> classMarshaled() {
        return byte[].class;
    }

    @Override
    public void write(@NotNull Excerpt excerpt, @NotNull byte[] bytes) {
        excerpt.writeStopBit(bytes.length);
        excerpt.write(bytes);
    }

    @NotNull
    @Override
    public byte[] read(@NotNull Excerpt excerpt) {
        int len = (int) excerpt.readStopBit();
        byte[] bytes = new byte[len];
        excerpt.read(bytes);
        return bytes;
    }

    @Override
    public byte[] parse(@NotNull Excerpt excerpt, @NotNull StopCharTester tester) {
        return excerpt.parseUTF(tester).getBytes(Charset.forName("UTF-8"));
    }
}
