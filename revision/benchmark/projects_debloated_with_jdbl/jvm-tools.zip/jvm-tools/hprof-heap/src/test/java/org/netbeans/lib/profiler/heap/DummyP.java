package org.netbeans.lib.profiler.heap;

public class DummyP {

	String key;
	Object value;
	
	public DummyP(String key, Object value) {
		this.key = key;
		this.value = value;
	}
}
