package org.gridkit.jvmtool.osdiag;

public class TimeInfoMS {

    public double elapsedTimeMs;
    public double cpuTimeMs;
    public double kernelTimeMs;
    
}
