package org.gridkit.jvmtool.event;

public interface ErrorHandler {

    public boolean onException(Exception e);

}
