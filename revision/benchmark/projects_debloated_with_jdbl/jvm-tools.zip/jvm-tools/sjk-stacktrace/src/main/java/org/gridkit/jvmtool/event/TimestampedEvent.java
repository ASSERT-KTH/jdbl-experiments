package org.gridkit.jvmtool.event;

public interface TimestampedEvent {

    public long timestamp();

}
