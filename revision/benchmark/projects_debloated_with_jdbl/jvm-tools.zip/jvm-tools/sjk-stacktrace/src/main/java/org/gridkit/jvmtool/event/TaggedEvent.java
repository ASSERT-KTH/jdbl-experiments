package org.gridkit.jvmtool.event;

public interface TaggedEvent extends Event {

    public TagCollection tags();

}
