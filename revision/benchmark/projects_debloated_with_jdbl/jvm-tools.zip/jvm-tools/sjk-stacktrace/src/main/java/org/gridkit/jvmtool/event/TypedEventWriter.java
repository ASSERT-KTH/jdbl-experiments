package org.gridkit.jvmtool.event;

/**
 * Marker interface.
 *
 * @author Alexey Ragozin (alexey.ragozin@gmail.com)
 */
public interface TypedEventWriter {

    public void close();

}
