package org.gridkit.jvmtool.event;

public interface EventPredicate<T extends Event> extends EventMorpher<T, T> {

}