`gc` command
============

Reports GC events from target JVM.

Usage
-----

    > java -jar sjk.jar --help gc
    Usage: gc [options]
      Options:
            --help
    
           Default: false
        -p, --pid
           JVM process PID
        -s, --socket
           Socket address for JMX port (host:port)
