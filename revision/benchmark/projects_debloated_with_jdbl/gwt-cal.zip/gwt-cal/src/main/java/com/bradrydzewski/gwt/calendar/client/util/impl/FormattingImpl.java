package com.bradrydzewski.gwt.calendar.client.util.impl;

public class FormattingImpl {

	public int getBorderOffset() {
		return -1;
	}
}
