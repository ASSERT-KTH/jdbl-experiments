package com.bradrydzewski.gwt.calendar.client;

public interface HasSettings {

	public CalendarSettings getSettings();
	public void setSettings(CalendarSettings settings);
}
