package com.bradrydzewski.gwt.calendar.client.util.impl;

public class FormattingIE6Impl extends FormattingImpl {

	@Override
	public int getBorderOffset() {
		return 0;
	}
}
