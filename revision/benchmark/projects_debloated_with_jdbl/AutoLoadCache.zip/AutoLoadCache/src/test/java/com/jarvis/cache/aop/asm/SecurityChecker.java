package com.jarvis.cache.aop.asm;

/**
 * @author: jiayu.qiu
 */
public class SecurityChecker {

    public static void checkSecurity() {
        System.out.println("SecurityChecker.checkSecurity ...");
        // TODO real security check
    }
}
