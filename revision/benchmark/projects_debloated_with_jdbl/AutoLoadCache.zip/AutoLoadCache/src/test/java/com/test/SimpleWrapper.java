package com.test;

import com.jarvis.cache.to.CacheWrapper;

/**
 * @author: jiayu.qiu
 */
public class SimpleWrapper extends CacheWrapper {

    private static final long serialVersionUID=1L;

}
