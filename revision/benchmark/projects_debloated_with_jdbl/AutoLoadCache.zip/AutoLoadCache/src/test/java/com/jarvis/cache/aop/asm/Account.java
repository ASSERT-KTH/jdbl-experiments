package com.jarvis.cache.aop.asm;

/**
 * @author: jiayu.qiu
 */
public class Account {

    public void operation(String t) {
        System.out.println("operation..." + t);
        // TODO real operation
    }
}
