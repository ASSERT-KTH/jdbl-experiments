package com.jarvis.cache.exception;

/**
 * 链接缓存中心失败异常
 * 
 * @author jiayu.qiu
 */
public class CacheCenterConnectionException extends Exception {

    private static final long serialVersionUID = -5840105373358438532L;

}
